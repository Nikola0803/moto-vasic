export default function StickyMobileBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#1A1A1A] border-t border-white/10 shadow-[0_-4px_20px_rgba(0,0,0,0.3)] md:hidden">
      <div className="flex items-center gap-2 px-3 py-2.5">
        <div className="flex-1 flex items-center gap-2">
          <div className="w-9 h-9 flex items-center justify-center bg-brand-600 rounded-lg shrink-0">
            <i className="ri-phone-line text-white text-sm" />
          </div>
          <div className="flex-1">
            <a
              href="tel:+381666665170"
              className="flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-500 text-white font-semibold py-2.5 rounded-lg text-[13px] whitespace-nowrap w-full"
            >
              Nazovi i naruči
            </a>
          </div>
        </div>
        <a
          href="https://wa.me/381666665170"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center w-11 h-11 bg-emerald-600 rounded-lg shrink-0"
          aria-label="WhatsApp"
        >
          <i className="ri-whatsapp-line text-white text-lg" />
        </a>
      </div>
    </div>
  );
}